struct Laptop {
    brand: String,
    quantity: u32,
    price: u32,
}

impl Laptop {
    // Method to calculate total cost for purchasing a given quantity of laptops
    fn total_cost(&self, qty_purchased: u32) -> u32 {
        self.price * qty_purchased
    }
}

fn main() {
    // Initialize the laptop consignment data
    let hp = Laptop {
        brand: String::from("HP"),
        quantity: 10,
        price: 650_000,
    };

    let ibm = Laptop {
        brand: String::from("IBM"),
        quantity: 6,
        price: 755_000,
    };

    let toshiba = Laptop {
        brand: String::from("Toshiba"),
        quantity: 10,
        price: 550_000,
    };

    let dell = Laptop {
        brand: String::from("Dell"),
        quantity: 4,
        price: 850_000,
    };

    // Customer purchases 3 laptops from each brand
    let qty_to_buy = 3;

    let hp_cost = hp.total_cost(qty_to_buy);
    let ibm_cost = ibm.total_cost(qty_to_buy);
    let toshiba_cost = toshiba.total_cost(qty_to_buy);
    let dell_cost = dell.total_cost(qty_to_buy);

    let grand_total = hp_cost + ibm_cost + toshiba_cost + dell_cost;

    // Output the results
    println!("=== Alaba Electronics Consignment Calculation ===");
    println!("Cost for {} {} laptops: N{}", qty_to_buy, hp.brand, hp_cost);
    println!("Cost for {} {} laptops: N{}", qty_to_buy, ibm.brand, ibm_cost);
    println!("Cost for {} {} laptops: N{}", qty_to_buy, toshiba.brand, toshiba_cost);
    println!("Cost for {} {} laptops: N{}", qty_to_buy, dell.brand, dell_cost);
    println!("-------------------------------------------------");
    println!("Total combined cost for {} laptops from each brand: N{}", qty_to_buy, grand_total);
}
fn main() {
   let developers = vec![

        ("Ikenna", 8),

        ("Justin", 1),

        ("Fred", 6),

        ("Albert", 8),

        ("Dickson", 3),

    ];

    let mut highest_name = developers[0].0;
    let mut highest_years = developers[0].1;

    for (name, years) in &developers {
        if *years > highest_years {
            highest_name = *name;
            highest_years = *years;
        }
    }

    println!("EY INTERVIEW RESULTS");
    println!("Developer with the highest experience: {}", highest_name);
    println!("Years of programming experience: {}", highest_years);
}
use std::io;

fn main() {
    let aps_levels = vec![
        (1, 2, "APS 1-2"),
        (3, 4, "APS 3-5"),
        (5, 8, "APS 5-8"),
        (9, 10, "EL1 8-10"),
        (11, 13, "EL2 10-13"),
    ];

    let positions = vec![
        ("Intern", "Paralegal", "Placement"),
        ("Administrator", "Junior Associate", "Classroom Teacher"),
        ("Senior Administrator", "Associate", "Senior Teacher"),
        ("Office Manager", "Senior Associate 1-2", "Leading Teacher"),
        ("Director", "Senior Associate 3-4", "Deputy Principal"),
    ];

    println!("APS LEVEL CHECKER");
    println!("Enter your profession:");
    println!("1. Office Admin");
    println!("2. Academic");
    println!("3. Lawyer");
    println!("4. Teacher");

    let mut profession = String::new();
    io::stdin().read_line(&mut profession).unwrap();

    let profession: usize = match profession.trim().parse() {
        Ok(number) if number >= 1 && number <= 4 => number,
        _ => {
            println!("Invalid profession.");
            return;
        }
    };

    println!("Enter your years of experience:");

    let mut experience = String::new();
    io::stdin().read_line(&mut experience).unwrap();

    let years: u32 = match experience.trim().parse() {
        Ok(number) => number,
        Err(_) => {
            println!("Please enter a valid number.");
            return;
        }
    };

    if years == 0 {
        println!("Experience must be at least 1 year.");
        return;
    }

    if years >= 14 {
        let senior_position = match profession {
            1 => "CEO",
            2 => "Dean",
            3 => "Partner",
            4 => "Principal",
            _ => unreachable!(),
        };

        println!("Level: SES");
        println!("Position: {}", senior_position);
        return;
    }

    for (index, (minimum, maximum, level)) in aps_levels.iter().enumerate() {
        if years >= *minimum && years <= *maximum {
            let position = match profession {
                1 => positions[index].0,
                2 => {
                    if index == 0 {
                        "-"
                    } else {
                        match index {
                            1 => "Research Assistant",
                            2 => "PhD Candidate",
                            3 => "Post-Doc Researcher",
                            4 => "Senior Lecturer",
                            _ => "-",
                        }
                    }
                }
                3 => positions[index].1,
                4 => positions[index].2,
                _ => unreachable!(),
            };

            println!("Level: {}", level);
            println!("Position: {}", position);
            return;
        }
    }

    println!("No matching APS level found.");
}
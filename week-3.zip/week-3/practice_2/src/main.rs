fn main() {
    let result = 10;
    let age: u32 = 20;
    let sum: i32 = 5 - 15;

    println!("result is {}", result);
    println!("age is {}", age);
    println!("sum is {}", sum);
}
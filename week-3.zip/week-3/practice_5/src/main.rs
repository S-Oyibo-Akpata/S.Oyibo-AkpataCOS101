fn main() {
    let alphabet: char = 'B';
    let surname = "Bolaji";

    println!("alphabet is {}", alphabet);
    println!("surname is {}", surname);
}
fn main() {
    let int_with_separator = 50_000;
    let decimal = 11_000.555_001;

    println!("Integer is {}", int_with_separator);
    println!("Decimal is {}", decimal);
}

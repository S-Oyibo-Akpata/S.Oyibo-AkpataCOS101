use std::io;

fn main() {
    // Display the menu
    println!("=============================================");
    println!("            THE RESTAURANT MENU              ");
    println!("=============================================");
    println!("P = Poundo Yam / Edinkaiko Soup  - N3,200");
    println!("F = Fried Rice & Chicken        - N3,000");
    println!("A = Amala & Ewedu Soup          - N2,500");
    println!("E = Eba & Egusi Soup            - N2,000");
    println!("W = White Rice & Stew           - N2,500");
    println!("=============================================\n");

    // Input food code
    println!("Enter the food code (P, F, A, E, W):");
    let mut food_code = String::new();
    io::stdin()
        .read_line(&mut food_code)
        .expect("Failed to read line");
    let food_code = food_code.trim().to_uppercase();

    // Input quantity
    println!("Enter the quantity:");
    let mut quantity_str = String::new();
    io::stdin()
        .read_line(&mut quantity_str)
        .expect("Failed to read line");
    let quantity: f64 = quantity_str
        .trim()
        .parse()
        .expect("Please enter a valid number");

    let price_per_item: f64;
    let item_name: &str;

    // Determine item and unit price
    if food_code == "P" {
        item_name = "Poundo Yam / Edinkaiko Soup";
        price_per_item = 3200.0;
    } else if food_code == "F" {
        item_name = "Fried Rice & Chicken";
        price_per_item = 3000.0;
    } else if food_code == "A" {
        item_name = "Amala & Ewedu Soup";
        price_per_item = 2500.0;
    } else if food_code == "E" {
        item_name = "Eba & Egusi Soup";
        price_per_item = 2000.0;
    } else if food_code == "W" {
        item_name = "White Rice & Stew";
        price_per_item = 2500.0;
    } else {
        println!("Invalid food code selected!");
        return;
    }

    // Calculate total cost
    let initial_total = price_per_item * quantity;
    let mut final_total = initial_total;
    let mut discount = 0.0;

    // Check discount rule: > N10,000 gets 5% discount
    if initial_total > 10000.0 {
        discount = initial_total * 0.05;
        final_total = initial_total - discount;
    }

    // Output order summary
    println!("\n--- ORDER SUMMARY ---");
    println!("Item Ordered: {}", item_name);
    println!("Quantity: {}", quantity);
    println!("Subtotal: N{:.2}", initial_total);
    if discount > 0.0 {
        println!("Discount (5%): N{:.2}", discount);
    }
    println!("Total Amount Due: N{:.2}", final_total);
}
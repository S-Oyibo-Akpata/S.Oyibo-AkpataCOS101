use std::io::Write;

fn main() {
    // Categories and their respective drinks as arrays/vectors
    let lager = vec!["33 Export", "Desperados", "Goldberg", "Gulder", "Heineken", "Star"];
    let stout = vec!["Legend", "Turbo King", "Williams"];
    let non_alcoholic = vec!["Maltina", "Amstel Malta", "Malta Gold", "Fayrouz"];

    // Create and open a file named "nigerian_breweries.txt"
    let mut file = std::fs::File::create("nigerian_breweries.txt").expect("create failed");

    // Write headers
    file.write_all("NIGERIAN BREWERIES PLC - DRINK CATEGORIES\n".as_bytes()).expect("write failed");
    file.write_all("--------------------------------------------------\n".as_bytes()).expect("write failed");

    // Write Lager Category
    file.write_all("\n[Lager]\n".as_bytes()).expect("write failed");
    for drink in &lager {
        let line = format!("- {}\n", drink);
        file.write_all(line.as_bytes()).expect("write failed");
    }

    // Write Stout Category
    file.write_all("\n[Stout]\n".as_bytes()).expect("write failed");
    for drink in &stout {
        let line = format!("- {}\n", drink);
        file.write_all(line.as_bytes()).expect("write failed");
    }

    // Write Non-Alcoholic Category
    file.write_all("\n[Non-Alcoholic]\n".as_bytes()).expect("write failed");
    for drink in &non_alcoholic {
        let line = format!("- {}\n", drink);
        file.write_all(line.as_bytes()).expect("write failed");
    }

    println!("\nProject I data successfully written to 'nigerian_breweries.txt'.");
}
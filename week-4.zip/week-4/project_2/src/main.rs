use std::io;

fn main() {

    // Experience
    let mut experience = String::new();

    println!("Are you experienced? (yes/no)");

    io::stdin()
        .read_line(&mut experience)
        .expect("Failed to read input");

    let experience = experience.trim();

    // Age
    let mut age = String::new();

    println!("Enter your age:");

    io::stdin()
        .read_line(&mut age)
        .expect("Failed to read input");

    let age: i32 = age.trim().parse().expect("Input not an integer");

    // Decision

    if experience == "yes" && age >= 40 {

        println!("Annual incentive = N1,560,000");

    } else if experience == "yes" && age >= 30 && age <= 39 {

        println!("Annual incentive = N1,480,000");

    } else if experience == "yes" && age < 28 {

        println!("Annual incentive = N1,300,000");

    } else {

        println!("Annual incentive = N100,000");

    }
}
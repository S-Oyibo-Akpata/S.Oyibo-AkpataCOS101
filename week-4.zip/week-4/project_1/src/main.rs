use std::io;

fn main() {

    // Input a
    let mut input = String::new();

    println!("Enter value of a:");
    io::stdin()
        .read_line(&mut input)
        .expect("Failed to read input");

    let a: f64 = input.trim().parse().expect("Input not a number");

    // Input b
    let mut input = String::new();

    println!("Enter value of b:");
    io::stdin()
        .read_line(&mut input)
        .expect("Failed to read input");

    let b: f64 = input.trim().parse().expect("Input not a number");

    // Input c
    let mut input = String::new();

    println!("Enter value of c:");
    io::stdin()
        .read_line(&mut input)
        .expect("Failed to read input");

    let c: f64 = input.trim().parse().expect("Input not a number");

    // Discriminant
    let d = b * b - 4.0 * a * c;

    if d > 0.0 {

        let x1 = (-b + d.sqrt()) / (2.0 * a);
        let x2 = (-b - d.sqrt()) / (2.0 * a);

        println!("Two distinct roots:");
        println!("Root 1 = {}", x1);
        println!("Root 2 = {}", x2);

    } else if d == 0.0 {

        let x = -b / (2.0 * a);

        println!("One real root:");
        println!("Root = {}", x);

    } else {

        println!("No real roots");

    }
}